
//<--------------------------------------------------------------------------------------------->
import java.util.HashMap;//For handling data with Key-value pair
import java.util.Scanner;//To take Input from user
import com.google.gson.Gson;//HashMap to JSON format

//<----------------------------------------------------------------------------------------------->
public class Election
{	
//<-------Creating Object of HashMap--------------------->
	 HashMap<String, Integer> candidates = new HashMap<String, Integer>();
	
//1>------Enter-candidate method to add candidate information in HashMap with initial value 0 ----->
	 public  void entercandidate( String name)
    	{		          
            candidates.put(name, 0);
            System.out.println("Candidate Name: " + name);       
    	}
	 
//2>-----Cast-vote method: a)check name is valid or not b)user able to cast their vote------------>
	 public int castvote(String name) 
	 {
	        if (!candidates.containsKey(name)) 
	        {
	            System.out.println("Sorry for Inconvenience, Please enter a valid candidate name.");
	            return 0;
	        }
	        
	        int voteCount = candidates.get(name);
	        candidates.put(name, voteCount + 1);
	        return voteCount + 1;
	 }
	 
//3>-----count-vote method: a)check name is valid or not b)return total count of vote------------>
	    public int countvote(String name) 
	    {
	        if (!candidates.containsKey(name))//Returns true if this map contains a mapping for thespecified key
	        {
	            System.out.println("Sorry for Inconvenience, Please enter a valid candidate name.");
	            return 0;
	        }
	        return candidates.get(name);
	    }
	 
//4>--------list-vote method: return JSON format------------------------------------------------->
	    public String listvote() 
	    {
	        Gson gson = new Gson();
	        return gson.toJson(candidates);
	    }
  
//5>-----------get-winner method: Display winner------------------------------------------------->
	    public void getwinner()
	    {
	    	String winner = "";
            int maxVotes = 0;
            for (String name : candidates.keySet())//Returns a Set view of the keys contained in this map
            {
                int voteCount = candidates.get(name);//Returns the value to which the specified key is mapped
                if (voteCount > maxVotes)
                {
                    maxVotes = voteCount;
                    winner = name;                       
                }
            }               
            System.out.println("Winner: " + winner + " with " + maxVotes + " votes.");
        } 
	    
//<------------------------------main method------------------------------------------------------------------------->

    public static void main(String[] args) 
    {
        @SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);        
        Election election = new Election();

        boolean flag=true;        
        while (flag) 
        {    
        	System.out.println(" ");              
        	System.out.print(" 1.entercandidate");
        	System.out.print(" 2.castvote");
        	System.out.print(" 3.countvote");
        	System.out.print(" 4.listvote");
        	System.out.print(" 5.getwinner");
        	System.out.print(" 6.exit");
        	System.out.println(" "); 
        	System.out.println(" ");  
        	System.out.println("Enter your choice");
  
    //<----------------------------------------------------------------------------------------------------->
        	 String str = scanner.nextLine(); //Take Input          
             String[] parts = str.split(" "); //split method return array of string                     
             String command = parts[0];      //first element/value assign to the command variable
            
    //<------------------switch case control instruction---------------------------------------------------->        
               switch(command)
               {
               case "entercandidate":           	            	   
            	   election.entercandidate(parts[1]);
            	   break;
              
               
               case "castvote":
            	    int voteCount= election.castvote(parts[1]);
            	    System.out.println("Vote cast for " + parts[1] + ". Total vote count: " + voteCount);
                    break;
                    
               case "countvote":
            	  int totalVote= election.countvote(parts[1]);
            	   System.out.println("Vote count for " + parts[1] + ": " + totalVote);
            	   break;
            	   
               case "listvote":
            	   String str1=election.listvote();
            	   System.out.println(str1);
            	   break;
            	
               case "getwinner":
            	   election.getwinner();
            	   break;
            	 
               case "exit":
            	   flag=false;
            	   break;
            	   
               default:
           		System.out.println("Invalid Choice");
               }  
    //<-------------------------------------------------------------------------------------------------------->           
        }       
    }
}

